import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frmPrin {
    public JPanel jpPrin;
    private JPanel jpPagFin;
    private JPanel jpPagCen;
    private JButton btnMostNom;
    private JTextField txtNom;


    public frmPrin() {

    }

    private void gesEve8(){
        txtNom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Bienvenido: " + txtNom.getText(), "MENSAJE", JOptionPane.INFORMATION_MESSAGE) ;;
            }
        });
    }
}
